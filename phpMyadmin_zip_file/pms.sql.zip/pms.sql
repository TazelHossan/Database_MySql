-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 06, 2020 at 12:23 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pms`
--

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE IF NOT EXISTS `drugs` (
  `mid` int(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `mtype` varchar(30) NOT NULL,
  `mcost` int(30) NOT NULL,
  `mav` varchar(30) NOT NULL,
  `mdate` date NOT NULL,
  `mimg` text NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`mid`, `mname`, `mtype`, `mcost`, `mav`, `mdate`, `mimg`) VALUES
(111, 'NAPA', 'GOOD', 30, 'YES', '2019-11-06', ''),
(222, 'Parasitamol', 'GOOD', 40, 'YES', '2019-11-06', '1.jpg');
